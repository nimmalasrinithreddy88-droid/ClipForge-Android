package com.clipforge.app

import android.content.ContentValues
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.SpannableString
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * ClipForge v0.2 starter.
 * Implements single-video trim, optional music bed, static text overlay,
 * grayscale/invert filters, and MP4 export. This is not yet a multi-clip
 * draggable timeline editor; see README for the next milestones.
 */
@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private var selectedVideo: Uri? = null
    private var selectedMusic: Uri? = null
    private var filterMode = 0 // 0 original, 1 grayscale, 2 inverted
    private var transformer: Transformer? = null

    private lateinit var status: TextView
    private lateinit var startSeconds: EditText
    private lateinit var endSeconds: EditText
    private lateinit var overlayText: EditText
    private lateinit var filterButton: Button
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar

    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            status.text = "Video selected. Add optional music/text, choose a filter, then export."
            exportButton.isEnabled = true
        }
    }

    private val musicPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedMusic = uri
            status.text = "Music selected. It will be mixed as a background audio sequence."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(Color.rgb(17, 17, 27))
        }
        val scroll = ScrollView(this).apply { addView(page) }

        page.addView(TextView(this).apply {
            text = "ClipForge"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "MAKE EVERY SECOND COUNT"
            textSize = 12f
            setTextColor(Color.rgb(190, 174, 255))
            setPadding(0, dp(3), 0, dp(18))
        })

        page.addView(section("1 · VIDEO CLIP"))
        page.addView(button("Choose video") { videoPicker.launch("video/*") }, fullWidth())
        page.addView(label("Trim start (seconds)"))
        startSeconds = input("0")
        page.addView(startSeconds, fullWidth())
        page.addView(label("Trim end (seconds)"))
        endSeconds = input("10")
        page.addView(endSeconds, fullWidth())

        page.addView(section("2 · TEXT OVERLAY"))
        overlayText = input("Your text here")
        overlayText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        overlayText.setSingleLine(true)
        page.addView(overlayText, fullWidth())
        page.addView(label("A static text overlay is burned into the exported video."))

        page.addView(section("3 · MUSIC"))
        page.addView(button("Choose background music (optional)") {
            musicPicker.launch("audio/*")
        }, fullWidth())
        page.addView(label("Music mixing depends on the selected file's codec and device support."))

        page.addView(section("4 · FILTER"))
        filterButton = button("Filter: Original") { cycleFilter() }
        page.addView(filterButton, fullWidth())
        page.addView(label("Tap to cycle Original → Black & white → Inverted."))

        page.addView(section("5 · EXPORT"))
        exportButton = button("Export MP4 to Gallery") { exportVideo() }
        exportButton.isEnabled = false
        page.addView(exportButton, fullWidth())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
        }
        page.addView(progress, fullWidth())

        status = TextView(this).apply {
            text = "Choose a video to begin."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(8))
        }
        page.addView(status, fullWidth())

        page.addView(TextView(this).apply {
            text = "Current build: single video clip with trim, one static text overlay, one optional music track, and two simple filters. A draggable multi-clip timeline, preview player, timed text, and richer effects are still planned."
            textSize = 12f
            setTextColor(Color.rgb(170, 170, 192))
            setPadding(0, dp(18), 0, 0)
        }, fullWidth())

        setContentView(scroll)
    }

    private fun cycleFilter() {
        filterMode = (filterMode + 1) % 3
        filterButton.text = when (filterMode) {
            1 -> "Filter: Black & white"
            2 -> "Filter: Inverted"
            else -> "Filter: Original"
        }
    }

    private fun exportVideo() {
        val videoUri = selectedVideo ?: run {
            toast("Choose a video first")
            return
        }
        val start = startSeconds.text.toString().toLongOrNull()
        val end = endSeconds.text.toString().toLongOrNull()
        if (start == null || end == null || start < 0 || end <= start) {
            toast("Enter valid trim times. End must be greater than start.")
            return
        }

        val output = File(cacheDir, "clipforge_${System.currentTimeMillis()}.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start * 1000)
            .setEndPositionMs(end * 1000)
            .build()
        val inputItem = MediaItem.Builder().setUri(videoUri)
            .setClippingConfiguration(clipping).build()

        val videoEffects = mutableListOf<androidx.media3.common.Effect>()
        if (filterMode == 1) videoEffects.add(RgbFilter.createGrayscaleFilter())
        if (filterMode == 2) videoEffects.add(RgbFilter.createInvertedFilter())

        val text = overlayText.text.toString().trim()
        if (text.isNotEmpty() && text != "Your text here") {
            val overlay = TextOverlay.createStaticTextOverlay(SpannableString.valueOf(text))
            videoEffects.add(OverlayEffect(listOf(overlay)))
        }

        val editedVideo = EditedMediaItem.Builder(inputItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(listOf(editedVideo))

        val composition = if (selectedMusic != null) {
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(selectedMusic!!))
                .setRemoveVideo(true)
                .build()
            val musicSequence = EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
                .buildUpon()
                .setIsLooping(true)
                .build()
            Composition.Builder(videoSequence, musicSequence).build()
        } else {
            Composition.Builder(videoSequence).build()
        }

        exportButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.progress = 0
        status.text = "Exporting MP4… keep ClipForge open."

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                progress.visibility = ProgressBar.GONE
                exportButton.isEnabled = true
                saveToGallery(output)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                progress.visibility = ProgressBar.GONE
                exportButton.isEnabled = true
                status.text = "Export failed: ${exportException.message ?: "unsupported media"}"
                toast("Export failed. Try a short MP4/H.264 video and a common audio file.")
            }
        }

        transformer = Transformer.Builder(this).addListener(listener).build()
        try {
            transformer?.start(composition, output.absolutePath)
        } catch (e: Exception) {
            progress.visibility = ProgressBar.GONE
            exportButton.isEnabled = true
            status.text = "Could not start export: ${e.message ?: "unknown error"}"
        }
    }

    private fun saveToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Gallery could not create a file")
            contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not write output")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            }
            status.text = "Export complete! Saved to Gallery → Movies/ClipForge."
            toast("Video saved to Gallery")
        } catch (e: Exception) {
            status.text = "Export finished, but Gallery save failed: ${e.message ?: "unknown error"}"
            toast("Export finished; Gallery save failed")
        }
    }

    private fun section(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        setTextColor(Color.rgb(190, 174, 255))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun button(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(4), 0, dp(6))
    }

    private fun input(value: String) = EditText(this).apply {
        hint = value
        setText(value)
        textSize = 16f
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(Color.rgb(37, 37, 55))
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(6) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
