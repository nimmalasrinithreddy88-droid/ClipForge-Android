# ClipForge — phone-first Android starter (v0.2.0)

## Current implementation in source
- Native Android/Kotlin project
- Choose one video with the system picker
- Set start and end trim times in seconds
- Optional single static text overlay
- Optional audio file as looping background music sequence
- Original, grayscale, and inverted color filters
- MP4 export through AndroidX Media3 Transformer
- Save exported file into Movies/ClipForge in Gallery

## Important status
This source project has NOT been compiled or device-tested in this environment. API compatibility, codec behavior, music mixing, and export behavior must be verified on a real Android device before distribution. It is a development starter, not a Play Store-ready release.

The current version is not yet a full professional editor:
- no draggable multi-clip timeline
- no video preview/scrubber
- text overlay is static for the whole export
- music mixing/looping behavior needs device testing
- no ad SDK, Play Billing, privacy policy, or store listing
- no signed release bundle

## Build prerequisites
- JDK 17
- Android SDK platform 36 and matching build tools
- Gradle compatible with Android Gradle Plugin 8.10.1
- Internet access to download Gradle and Android dependencies

## Phone-only path
1. Download the ZIP to your phone.
2. Try a cloud workspace if your account includes one. Do not pay solely for this project yet.
3. Upload/extract the project so the root contains `settings.gradle.kts`, `build.gradle.kts`, and `app/`.
4. In a terminal with Java 17, Android SDK 36, and Gradle installed, run `gradle assembleDebug` (or create/use a Gradle wrapper).
5. If the build succeeds, download `app/build/outputs/apk/debug/app-debug.apk`, install it, and test using a short MP4/H.264 file.
6. Fix any build/device issues before implementing more features.

## Next milestones
1. Add ExoPlayer preview and a draggable timeline.
2. Support multiple video clips and split/reorder controls.
3. Add timed text and style controls.
4. Add music volume and trim/offset controls.
5. Add progress reporting, cancel export, robust error recovery.
6. Test across devices and codecs.
7. Only then add ads/Billing, privacy policy, release signing, store assets, and Play Console submission.

## Official technical references
- https://developer.android.com/media/media3/transformer/getting-started
- https://developer.android.com/media/media3/transformer/composition
- https://developer.android.com/reference/androidx/media3/effect/RgbFilter
- https://developer.android.com/reference/androidx/media3/effect/TextOverlay
